package main;

public class TimeIntegration {

    private TimeIntegration() {
    }

    public static void updateCellAverages(Cell[][] cells, int rkStep, double dt) {
        // Assuming dx, dy are constants
        double area = cells[0][0].dx * cells[0][0].dy;
        switch (Config.NUM_RK_STEPS) {
            case 1: // 1 step RK method
                for (int i = Config.NUM_GHOST_CELLS; i < Config.NUM_X_CELLS + Config.NUM_GHOST_CELLS; i++) {
                    for (int j = Config.NUM_GHOST_CELLS; j < Config.NUM_Y_CELLS + Config.NUM_GHOST_CELLS; j++) {
                        for (int var = 0; var < Cell.NUM_VARS; var++) {
                            cells[i][j].U[rkStep + 1][var] = cells[i][j].U[rkStep][var] + dt / area * cells[i][j].totalFlux[var];
                        }
                    }
                }
                break;
            case 2: // 2 step RK method
                for (int i = Config.NUM_GHOST_CELLS; i < Config.NUM_X_CELLS + Config.NUM_GHOST_CELLS; i++) {
                    for (int j = Config.NUM_GHOST_CELLS; j < Config.NUM_Y_CELLS + Config.NUM_GHOST_CELLS; j++) {
                        for (int var = 0; var < Cell.NUM_VARS; var++) {
                            switch (rkStep) {
                                case 0: // step 0

                                    cells[i][j].U[rkStep + 1][var]
                                            = cells[i][j].U[rkStep][var]
                                            + dt / area * cells[i][j].totalFlux[var];
                                    break;
                                case 1: // step 1
                                    cells[i][j].U[rkStep + 1][var]
                                            = 0.5 * (cells[i][j].U[rkStep - 1][var]
                                            + cells[i][j].U[rkStep][var]
                                            + dt / area * cells[i][j].totalFlux[var]);
                                    break;
                                default:
                                    throw new IllegalStateException("Must not reach here!! Something went wrong!");
                            }
                        }
                    }
                }
                break;
            case 3: // 3 step RK method
                for (int i = Config.NUM_GHOST_CELLS; i < Config.NUM_X_CELLS + Config.NUM_GHOST_CELLS; i++) {
                    for (int j = Config.NUM_GHOST_CELLS; j < Config.NUM_Y_CELLS + Config.NUM_GHOST_CELLS; j++) {
                        for (int var = 0; var < Cell.NUM_VARS; var++) {
                            switch (rkStep) {
                                case 0: // step 0
                                    cells[i][j].U[rkStep + 1][var]
                                            = cells[i][j].U[rkStep][var]
                                            + dt / area * cells[i][j].totalFlux[var];
                                    break;
                                case 1: // step 1
                                    cells[i][j].U[rkStep + 1][var]
                                            = 3.0 / 4.0 * cells[i][j].U[rkStep - 1][var]
                                            + 1.0 / 4.0 * cells[i][j].U[rkStep][var]
                                            + 1.0 / 4.0 * dt / area * cells[i][j].totalFlux[var];
                                    break;
                                case 2: // step 2
                                    cells[i][j].U[rkStep + 1][var]
                                            = 1.0 / 3.0 * cells[i][j].U[rkStep - 2][var]
                                            + 2.0 / 3.0 * cells[i][j].U[rkStep][var]
                                            + 2.0 / 3.0 * dt / area * cells[i][j].totalFlux[var];
                                    break;
                                default:
                                    throw new IllegalStateException("Must not reach here!! Something went wrong!");
                            }
                        }
                    }
                }
                break;
            default:
                System.out.println("The " + Config.NUM_RK_STEPS + " step RK method is not defined yet!");
                throw new RuntimeException("The " + Config.NUM_RK_STEPS + " step RK method is not defined yet!");
        }
    }
}
