package weno.weno;

import weno.poly.LagrangePolynomial;
import java.util.concurrent.ConcurrentHashMap;
import weno.matrixsolver.MatrixSolver;
import weno.poly.Polynomial;

public class WENO {

    final static double EPS = 1e-6;
    final static double SMOOTH_POW = 2.0;
    final static ConcurrentHashMap<Integer, double[]> CACHED_LINEAR_WEIGHTS = new ConcurrentHashMap<>();

    public static void main(String[] args) {
        System.out.println("Testing Weno Code:");
        ReconstructedValues recont = new WENO()
                .getWenoReconstructedValues(new double[]{
            -0.932615014, -0.9639829962, -0.9857191788, -0.9976063813, -0.9995258306}, 3);
        System.out.println(recont);
        recont = new WENO()
                .getWenoReconstructedValues(new double[]{
            1, 3, 6, -10, 0}, 3);
        System.out.println(recont);
        recont = new WENO()
                .getWenoReconstructedValues(new double[]{
            1, 3, 6, -10, 0}, 3);
        System.out.println(recont);
        recont = new WENO()
                .getWenoReconstructedValues(new double[]{
            1, 3, 6}, 2);
        System.out.println(recont);
        recont = new WENO()
                .getWenoReconstructedValues(new double[]{
            2, 3, 6}, 2);
        System.out.println(recont);
        recont = new WENO()
                .getWenoReconstructedValues(new double[]{
            -0.932615014, -0.9639829962, -0.9857191788, -0.9976063813, -0.9995258306}, 3);
        System.out.println(recont);
    }

    /**
     * This method returns the <code>ReconstructedValaues</code> using WENO
     * method of arbitrary order for 1D problem. The degree of the reconstructed
     * polynomial will be at-most (2k-2) for smooth regions. The number of
     * average values passed must be equal to (2k-1). It is assumed that cell
     * size (delta x) is constant.
     *
     * @param averageValues average values of cells starting from left-most cell
     * to right-most cell.
     * @param k number of cells in sub-stencil (ENO stencils) or number of
     * sub-stencils or order of ENO stencils
     * @return
     */
    public ReconstructedValues getWenoReconstructedValues(double[] averageValues, int k) {
        if (averageValues.length != 2 * k - 1) {
            throw new IllegalArgumentException("The number of averages passed for k = "
                    + k + " must be " + (2 * k - 1));
        }
        // Calculte x-values centered around middle cell
        // i.e middle cell centroid is at x=0 and dx = 1
        double[] cx = new double[averageValues.length];
        double dx = 1.0;
        for (int i = 0; i < cx.length; i++) {
            cx[i] = (-k + 1 + i) * dx;
        }

        // Create sub-stencils
        int[][] enoStencils = new int[k][k];
        for (int stencilNum = 0; stencilNum < k; stencilNum++) {
            for (int i = 0; i < k; i++) {
                enoStencils[stencilNum][i] = stencilNum + i;
            }
        }

        double[] linearWeights;
        if (!areLinearWeightsCached(k)) {
            System.out.println("Calculating linear weights for k = " + k);
            // Reconstruct polynomial for complete stencil (2k-1)
            double[] coeffsMainStencil = getReconstFunctionCoeffs(cx, averageValues, dx, dx / 2.0);

            // Reconstruct sub-stencils
            double[][] coeffsSubStencil = new double[enoStencils.length][k];
            for (int subStencil = 0; subStencil < enoStencils.length; subStencil++) {
                double[] sub_cx = new double[k];
                double[] sub_averageValues = new double[k];
                for (int i = 0; i < k; i++) {
                    sub_cx[i] = cx[enoStencils[subStencil][i]];
                    sub_averageValues[i] = averageValues[enoStencils[subStencil][i]];
                }
                coeffsSubStencil[subStencil] = getReconstFunctionCoeffs(sub_cx, sub_averageValues, dx, dx / 2.0);
            }

            // Calculate the linear weights
            // Create the linear weight system
            double[][] coeffMatrix = new double[averageValues.length + 1][k];
            for (int i = 0; i < enoStencils.length; i++) {
                for (int j = 0; j < enoStencils[i].length; j++) {
                    int row = enoStencils[i][j];
                    int col = i;
                    double coeff = coeffsSubStencil[i][j];
                    coeffMatrix[row][col] = coeff;
                }
            }
            // rhs
            double[] b = new double[averageValues.length + 1];
            System.arraycopy(coeffsMainStencil, 0, b, 0, coeffsMainStencil.length);

            // last row: sum(linearWeights) = 1
            for (int i = 0; i < k; i++) {
                coeffMatrix[coeffMatrix.length - 1][i] = 1.0;
            }
            b[b.length - 1] = 1.0;

            // Create a least-square system
            double[][] transCoeffMatrix = transposeMatrix(coeffMatrix);
            double[][] matrixA = multiplyMatrices(transCoeffMatrix, coeffMatrix);
            double[] rhs = multiplyMatrixVector(transCoeffMatrix, b);
            linearWeights = MatrixSolver.gaussElim(matrixA, rhs);

            CACHED_LINEAR_WEIGHTS.put(k, linearWeights);
        } else {
            // System.out.println("Using cached values");
            linearWeights = getCachedLinearWeights(k);
        }

        // Calculate the non-linear weights:
        // Create sub-stencil polynomials
        Polynomial[] subStencilPolys = new Polynomial[enoStencils.length];
        for (int subStencil = 0; subStencil < enoStencils.length; subStencil++) {
            double[] sub_cx = new double[k];
            double[] sub_averageValues = new double[k];
            for (int i = 0; i < k; i++) {
                sub_cx[i] = cx[enoStencils[subStencil][i]];
                sub_averageValues[i] = averageValues[enoStencils[subStencil][i]];
            }
            subStencilPolys[subStencil] = getReconstPolynomial(sub_cx, sub_averageValues, dx);
        }
        // calculate smoothness indicators
        double[] smoothnessIndicators = new double[enoStencils.length];
        for (int i = 0; i < smoothnessIndicators.length; i++) {
            smoothnessIndicators[i] = smoothnessIndicator(subStencilPolys[i], k, dx);
        }

        double[] p_iph_subStencils = new double[enoStencils.length];
        double[] p_imh_subStencils = new double[enoStencils.length];
        for (int i = 0; i < subStencilPolys.length; i++) {
            p_iph_subStencils[i] = subStencilPolys[i].getValueAt(dx / 2.0);
            p_imh_subStencils[i] = subStencilPolys[i].getValueAt(-dx / 2.0);
        }

        double p_iph = 0.0;
        double weightSum = 0.0;
        double[] nonLinearWeights = new double[enoStencils.length];
        for (int i = 0; i < enoStencils.length; i++) {
            nonLinearWeights[i] = linearWeights[i] / Math.pow(EPS + smoothnessIndicators[i], SMOOTH_POW);
            weightSum += nonLinearWeights[i];
        }
        for (int i = 0; i < nonLinearWeights.length; i++) {
            nonLinearWeights[i] /= weightSum;
        }
        for (int i = 0; i < nonLinearWeights.length; i++) {
            p_iph += nonLinearWeights[i] * p_iph_subStencils[i];
        }

        double p_imh = 0.0;
        weightSum = 0.0;
        nonLinearWeights = new double[enoStencils.length];
        for (int i = 0; i < enoStencils.length; i++) {
            nonLinearWeights[i] = linearWeights[k - i - 1] / Math.pow(EPS + smoothnessIndicators[i], SMOOTH_POW);
            weightSum += nonLinearWeights[i];
        }
        for (int i = 0; i < nonLinearWeights.length; i++) {
            nonLinearWeights[i] /= weightSum;
        }
        for (int i = 0; i < nonLinearWeights.length; i++) {
            p_imh += nonLinearWeights[i] * p_imh_subStencils[i];
        }

        return new ReconstructedValues(p_imh, p_iph);
    }

    private static boolean areLinearWeightsCached(int k) {
        return CACHED_LINEAR_WEIGHTS.containsKey(k);
    }

    private static double[] getCachedLinearWeights(int k) {
        return CACHED_LINEAR_WEIGHTS.get(k);
    }

    private double[] getReconstFunctionCoeffs(double[] cx, double[] averageValues, double dx, double x) {
        double[] interfX = new double[averageValues.length + 1];
        double[] integInterfValues = new double[interfX.length];

        for (int i = 0; i < interfX.length; i++) {
            if (i == 0) {
                interfX[i] = cx[i] - dx / 2.0;
                integInterfValues[i] = 0.0;
            } else {
                interfX[i] = cx[i - 1] + dx / 2.0;
                integInterfValues[i] += integInterfValues[i - 1] + averageValues[i - 1] * dx;
            }
        }
        LagrangePolynomial lagrPolyMainStencil = new LagrangePolynomial(interfX, integInterfValues);
        double[] coeffs = new double[averageValues.length];
        for (int i = 0; i < coeffs.length; i++) {
            coeffs[i] = lagrPolyMainStencil.lagrangeDiffCoeff(i + 1, x);
        }
        for (int i = 0; i < coeffs.length; i++) {
            double sum = 0;
            for (int j = i; j < coeffs.length; j++) {
                sum += coeffs[j];
            }
            coeffs[i] = sum;
        }

        return coeffs;
    }

    private Polynomial getReconstPolynomial(double[] cx, double[] averageValues, double dx) {
        double[] interfX = new double[averageValues.length + 1];
        double[] integInterfValues = new double[interfX.length];

        for (int i = 0; i < interfX.length; i++) {
            if (i == 0) {
                interfX[i] = cx[i] - dx / 2.0;
                integInterfValues[i] = 0.0;
            } else {
                interfX[i] = cx[i - 1] + dx / 2.0;
                integInterfValues[i] += integInterfValues[i - 1] + averageValues[i - 1] * dx;
            }
        }

        return Polynomial.interpolate(interfX, integInterfValues).differentiate();
    }

    private double smoothnessIndicator(Polynomial poly, int k, double dx) {
        double sum = 0.0;
        for (int l = 1; l <= k - 1; l++) {
            Polynomial diff = differentiate(poly, l);
            Polynomial integrand = diff.times(diff).times(Math.pow(dx, 2 * l - 1));
            sum += definiteIntegral(integrand, -dx / 2.0, dx / 2.0);
        }

        return sum;
    }

    private double definiteIntegral(Polynomial poly, double lowerLimit, double upperLimit) {
        poly = poly.integrate();
        return poly.getValueAt(upperLimit) - poly.getValueAt(lowerLimit);
    }

    private Polynomial differentiate(Polynomial polynomial, int n) {
        for (int i = 0; i < n; i++) {
            polynomial = polynomial.differentiate();
        }

        return polynomial;
    }

    private double[][] transposeMatrix(double[][] matrix) {
        double[][] transposedMatrix = new double[matrix[0].length][matrix.length];
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[0].length; j++) {
                transposedMatrix[j][i] = matrix[i][j];
            }
        }

        return transposedMatrix;
    }

    private double[][] multiplyMatrices(double[][] a, double[][] b) {
        int rowsInA = a.length;
        int columnsInA = a[0].length; // same as rows in B
        int columnsInB = b[0].length;
        double[][] c = new double[rowsInA][columnsInB];
        for (int i = 0; i < rowsInA; i++) {
            for (int j = 0; j < columnsInB; j++) {
                for (int k = 0; k < columnsInA; k++) {
                    c[i][j] = c[i][j] + a[i][k] * b[k][j];
                }
            }
        }
        return c;
    }

    private double[] multiplyMatrixVector(double[][] matrix, double[] vector) {
        int rowsInMatrix = matrix.length;
        int colsInMatrix = matrix[0].length; // Same as rows in vector
        double[] c = new double[rowsInMatrix];
        for (int i = 0; i < rowsInMatrix; i++) {
            for (int j = 0; j < colsInMatrix; j++) {
                c[i] = c[i] + matrix[i][j] * vector[j];
            }
        }

        return c;
    }

    private double sum(double[] values) {
        double sum = 0.0;
        for (int i = 0; i < values.length; i++) {
            sum += values[i];
        }

        return sum;
    }
}
