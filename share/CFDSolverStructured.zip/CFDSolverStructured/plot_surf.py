from mpl_toolkits.mplot3d import Axes3D

import numpy as np
import matplotlib.pyplot as plt
from glob import glob
import os
import sys

plt.ioff()

folderPath = "./out"
if len(sys.argv) == 2:
    folderPath = sys.argv[1]
print("Solution Folder Path: " + folderPath)

fileNames = glob(folderPath + "/Solution*.dat")
fileNames.sort()
fileNames = fileNames[0:]
numFiles = len(fileNames)
count = 0
trayHeight = None
zlim = None

fig = plt.figure()
for fileName in fileNames:
    count += 1
    ax = fig.gca(projection='3d')
    ax.set_axis_off()
    print(fileName, end=", ")
    print("Completed %.2f%%"%(count/numFiles * 100), flush=True)
    f = open(fileName, 'r')
    xCells = int(f.readline().split(":")[1])
    yCells = int(f.readline().split(":")[1])
    numGhostCells = int(f.readline().split(":")[1])
    time = float(f.readline().split(":")[1])
    f.close()
    
    x, y, h, hu, hv = np.loadtxt(fileName, skiprows=4, unpack=True)
    x = np.reshape(x, (xCells + 2 * numGhostCells, yCells + 2 * numGhostCells))[numGhostCells:-numGhostCells, numGhostCells:-numGhostCells]
    y = np.reshape(y, (xCells + 2 * numGhostCells, yCells + 2 * numGhostCells))[numGhostCells:-numGhostCells, numGhostCells:-numGhostCells]
    h = np.reshape(h, (xCells + 2 * numGhostCells, yCells + 2 * numGhostCells))[numGhostCells:-numGhostCells, numGhostCells:-numGhostCells]
    
    h[0,:] = 0; h[:,0]=0; h[-1,:]=0; h[:,-1]=0
    ax.plot_surface(x, y, h, rstride=1, cstride=1, linewidth=0,
                    color=(0.5, 0.5, 1.0, 1.0), shade=True, antialiased=False)
                    
    trayX = np.array([np.min(x), np.min(x) + 0.0001, np.max(x) - 0.0001, np.max(x)])
    trayY = np.array([np.min(y), np.min(y) + 0.0001, np.max(y) - 0.0001, np.max(y)])
    trayX, trayY = np.meshgrid(trayX, trayY)
    tray = np.zeros_like(trayX)
    if trayHeight == None: trayHeight = np.max(h) * 1.1
    tray[0,:] = trayHeight; tray[:,0] = trayHeight
    tray[-1,:] = trayHeight; tray[:,-1] = trayHeight
    ax.plot_surface(trayX, trayY, tray, rstride=1, cstride=1, linewidth=0, color=(0.5, 0.5, 0.5, 0.1))
    
    ax.set_xlim(np.min(x), np.max(x))
    ax.set_ylim(np.min(y), np.max(y))

    if zlim == None : zlim = np.max(h) * 1.2
    ax.set_zlim(-0.01, zlim)
    angle = count / numFiles * 90 + 45
    ax.view_init(45, -angle)
    
    plt.title("Time=%.4f"%time)
    fig.savefig(fileName.replace(".dat", ".png"))
    plt.clf()

#plt.show()
#os.system("eog " + fileNames[0].replace(".dat", ".png"))
