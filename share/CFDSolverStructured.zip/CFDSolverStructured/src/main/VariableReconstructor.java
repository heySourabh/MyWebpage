package main;

import java.util.stream.IntStream;
import weno.weno.ReconstructedValues;
import weno.weno.WENO;

public class VariableReconstructor {

    private VariableReconstructor() {
    }

    public static void reconstructVariables(Cell[][] cells, int rkStep) {
        switch (Config.RECONST_TYPE) {
            case FIRST_ORDER:
                for (int i = Config.NUM_GHOST_CELLS - 1;
                        i < Config.NUM_X_CELLS + Config.NUM_GHOST_CELLS + 1; i++) {
                    for (int j = Config.NUM_GHOST_CELLS - 1;
                            j < Config.NUM_Y_CELLS + Config.NUM_GHOST_CELLS + 1; j++) {
                        Cell cell = cells[i][j];
                        for (int var = 0; var < Cell.NUM_VARS; var++) {
                            cell.uWest[var] = cells[i][j].U[rkStep][var];
                            cell.uEast[var] = cells[i][j].U[rkStep][var];
                            cell.uSouth[var] = cells[i][j].U[rkStep][var];
                            cell.uNorth[var] = cells[i][j].U[rkStep][var];
                        }
                    }
                }
                break;
            case BEAM_WARMING:
                for (int i = Config.NUM_GHOST_CELLS - 1;
                        i < Config.NUM_X_CELLS + Config.NUM_GHOST_CELLS + 1; i++) {
                    for (int j = Config.NUM_GHOST_CELLS - 1;
                            j < Config.NUM_Y_CELLS + Config.NUM_GHOST_CELLS + 1; j++) {
                        for (int var = 0; var < Cell.NUM_VARS; var++) {
                            double du_dx = (cells[i][j].U[rkStep][var] - cells[i - 1][j].U[rkStep][var]) / cells[i][j].dx;
                            double du_dy = (cells[i][j].U[rkStep][var] - cells[i][j - 1].U[rkStep][var]) / cells[i][j].dy;

                            cells[i][j].uWest[var] = cells[i][j].U[rkStep][var] - du_dx * cells[i][j].dx / 2.0;
                            cells[i][j].uEast[var] = cells[i][j].U[rkStep][var] + du_dx * cells[i][j].dx / 2.0;

                            cells[i][j].uSouth[var] = cells[i][j].U[rkStep][var] - du_dy * cells[i][j].dy / 2.0;
                            cells[i][j].uNorth[var] = cells[i][j].U[rkStep][var] + du_dy * cells[i][j].dy / 2.0;
                        }
                    }
                }
                break;
            case LAX_WENDROFF:
                for (int i = Config.NUM_GHOST_CELLS - 1;
                        i < Config.NUM_X_CELLS + Config.NUM_GHOST_CELLS + 1; i++) {
                    for (int j = Config.NUM_GHOST_CELLS - 1;
                            j < Config.NUM_Y_CELLS + Config.NUM_GHOST_CELLS + 1; j++) {
                        for (int var = 0; var < Cell.NUM_VARS; var++) {
                            double du_dx = (cells[i + 1][j].U[rkStep][var] - cells[i][j].U[rkStep][var]) / cells[i][j].dx;
                            double du_dy = (cells[i][j + 1].U[rkStep][var] - cells[i][j].U[rkStep][var]) / cells[i][j].dy;

                            cells[i][j].uWest[var] = cells[i][j].U[rkStep][var] - du_dx * cells[i][j].dx / 2.0;
                            cells[i][j].uEast[var] = cells[i][j].U[rkStep][var] + du_dx * cells[i][j].dx / 2.0;

                            cells[i][j].uSouth[var] = cells[i][j].U[rkStep][var] - du_dy * cells[i][j].dy / 2.0;
                            cells[i][j].uNorth[var] = cells[i][j].U[rkStep][var] + du_dy * cells[i][j].dy / 2.0;
                        }
                    }
                }
                break;
            case FROMM:
                for (int i = Config.NUM_GHOST_CELLS - 1;
                        i < Config.NUM_X_CELLS + Config.NUM_GHOST_CELLS + 1; i++) {
                    for (int j = Config.NUM_GHOST_CELLS - 1;
                            j < Config.NUM_Y_CELLS + Config.NUM_GHOST_CELLS + 1; j++) {
                        for (int var = 0; var < Cell.NUM_VARS; var++) {
                            double du_dx = (cells[i + 1][j].U[rkStep][var] - cells[i - 1][j].U[rkStep][var]) / 2.0 / cells[i][j].dx;
                            double du_dy = (cells[i][j + 1].U[rkStep][var] - cells[i][j - 1].U[rkStep][var]) / 2.0 / cells[i][j].dy;

                            cells[i][j].uWest[var] = cells[i][j].U[rkStep][var] - du_dx * cells[i][j].dx / 2.0;
                            cells[i][j].uEast[var] = cells[i][j].U[rkStep][var] + du_dx * cells[i][j].dx / 2.0;

                            cells[i][j].uSouth[var] = cells[i][j].U[rkStep][var] - du_dy * cells[i][j].dy / 2.0;
                            cells[i][j].uNorth[var] = cells[i][j].U[rkStep][var] + du_dy * cells[i][j].dy / 2.0;
                        }
                    }
                }
                break;
            case LIMITED_LW:
                for (int i = Config.NUM_GHOST_CELLS - 1;
                        i < Config.NUM_X_CELLS + Config.NUM_GHOST_CELLS + 1; i++) {
                    for (int j = Config.NUM_GHOST_CELLS - 1;
                            j < Config.NUM_Y_CELLS + Config.NUM_GHOST_CELLS + 1; j++) {
                        for (int var = 0; var < Cell.NUM_VARS; var++) {
                            double numerator = cells[i][j].U[rkStep][var] - cells[i - 1][j].U[rkStep][var];
                            double denominator = cells[i + 1][j].U[rkStep][var] - cells[i][j].U[rkStep][var];
                            double r_x = numerator / denominator;
                            if (Math.abs(denominator) < 1e-15) {
                                r_x = 0.0;
                            }
                            r_x = Math.max(0, r_x);
                            double phi_x = (r_x * r_x + r_x) / (r_x * r_x + 1.0);

                            numerator = cells[i][j].U[rkStep][var] - cells[i][j - 1].U[rkStep][var];
                            denominator = cells[i][j + 1].U[rkStep][var] - cells[i][j].U[rkStep][var];
                            double r_y = numerator / denominator;
                            if (Math.abs(denominator) < 1e-15) {
                                r_y = 0.0;
                            }
                            r_y = Math.max(0, r_y);
                            double phi_y = (r_y * r_y + r_y) / (r_y * r_y + 1.0);

                            double du_dx = (cells[i + 1][j].U[rkStep][var] - cells[i][j].U[rkStep][var]) / cells[i][j].dx;
                            double du_dy = (cells[i][j + 1].U[rkStep][var] - cells[i][j].U[rkStep][var]) / cells[i][j].dy;

                            cells[i][j].uWest[var] = cells[i][j].U[rkStep][var] - phi_x * du_dx * cells[i][j].dx / 2.0;
                            cells[i][j].uEast[var] = cells[i][j].U[rkStep][var] + phi_x * du_dx * cells[i][j].dx / 2.0;

                            cells[i][j].uSouth[var] = cells[i][j].U[rkStep][var] - phi_y * du_dy * cells[i][j].dy / 2.0;
                            cells[i][j].uNorth[var] = cells[i][j].U[rkStep][var] + phi_y * du_dy * cells[i][j].dy / 2.0;
                        }
                    }
                }
                break;
            case LIMITED_BW:
                for (int i = Config.NUM_GHOST_CELLS - 1;
                        i < Config.NUM_X_CELLS + Config.NUM_GHOST_CELLS + 1; i++) {
                    for (int j = Config.NUM_GHOST_CELLS - 1;
                            j < Config.NUM_Y_CELLS + Config.NUM_GHOST_CELLS + 1; j++) {
                        for (int var = 0; var < Cell.NUM_VARS; var++) {
                            double numerator = cells[i + 1][j].U[rkStep][var] - cells[i][j].U[rkStep][var];
                            double denominator = cells[i][j].U[rkStep][var] - cells[i - 1][j].U[rkStep][var];
                            double r_x = numerator / denominator;
                            if (Math.abs(denominator) < 1e-15) {
                                r_x = 0.0;
                            }
                            r_x = Math.max(0, r_x);
                            double phi_x = (r_x * r_x + r_x) / (r_x * r_x + 1.0);

                            numerator = cells[i][j + 1].U[rkStep][var] - cells[i][j].U[rkStep][var];
                            denominator = cells[i][j].U[rkStep][var] - cells[i][j - 1].U[rkStep][var];
                            double r_y = numerator / denominator;
                            if (Math.abs(denominator) < 1e-15) {
                                r_y = 0.0;
                            }
                            r_y = Math.max(0, r_y);
                            double phi_y = (r_y * r_y + r_y) / (r_y * r_y + 1.0);

                            double du_dx = (cells[i][j].U[rkStep][var] - cells[i - 1][j].U[rkStep][var]) / cells[i][j].dx;
                            double du_dy = (cells[i][j].U[rkStep][var] - cells[i][j - 1].U[rkStep][var]) / cells[i][j].dy;

                            cells[i][j].uWest[var] = cells[i][j].U[rkStep][var] - phi_x * du_dx * cells[i][j].dx / 2.0;
                            cells[i][j].uEast[var] = cells[i][j].U[rkStep][var] + phi_x * du_dx * cells[i][j].dx / 2.0;

                            cells[i][j].uSouth[var] = cells[i][j].U[rkStep][var] - phi_y * du_dy * cells[i][j].dy / 2.0;
                            cells[i][j].uNorth[var] = cells[i][j].U[rkStep][var] + phi_y * du_dy * cells[i][j].dy / 2.0;
                        }
                    }
                }
                break;
            case WENO:
                IntStream.range(Config.NUM_GHOST_CELLS - 1, Config.NUM_X_CELLS + Config.NUM_GHOST_CELLS + 1)
                        .parallel()
                        .forEach(i -> {
                            for (int j = Config.NUM_GHOST_CELLS - 1;
                                    j < Config.NUM_Y_CELLS + Config.NUM_GHOST_CELLS + 1; j++) {
                                for (int var = 0; var < Cell.NUM_VARS; var++) {
                                    int k = 3;
                                    int numNeigh = k - 1;
                                    double[] averageValues = new double[2 * k - 1];
                                    for (int n = -numNeigh; n <= numNeigh; n++) {
                                        averageValues[n + numNeigh] = cells[i + n][j].U[rkStep][var];
                                    }
                                    ReconstructedValues values = new WENO().getWenoReconstructedValues(averageValues, k);
                                    cells[i][j].uWest[var] = values.value_imh;
                                    cells[i][j].uEast[var] = values.value_iph;

                                    for (int n = -numNeigh; n <= numNeigh; n++) {
                                        averageValues[n + numNeigh] = cells[i][j + n].U[rkStep][var];
                                    }
                                    values = new WENO().getWenoReconstructedValues(averageValues, k);
                                    cells[i][j].uSouth[var] = values.value_imh;
                                    cells[i][j].uNorth[var] = values.value_iph;
                                }
                            }
                        });

                break;
            case SDWLS_L:
                final double EPS = 1e-15;
                for (int i = Config.NUM_GHOST_CELLS - 1;
                        i < Config.NUM_X_CELLS + Config.NUM_GHOST_CELLS + 1; i++) {
                    for (int j = Config.NUM_GHOST_CELLS - 1;
                            j < Config.NUM_Y_CELLS + Config.NUM_GHOST_CELLS + 1; j++) {
                        for (int var = 0; var < Cell.NUM_VARS; var++) {
                            double u_ij = cells[i][j].U[rkStep][var];
                            double u_ip1j = cells[i + 1][j].U[rkStep][var];
                            double u_im1j = cells[i - 1][j].U[rkStep][var];
                            double u_ijp1 = cells[i][j + 1].U[rkStep][var];
                            double u_ijm1 = cells[i][j - 1].U[rkStep][var];
                            double dx = cells[i][j].dx;
                            double dy = cells[i][j].dy;

                            double du1 = u_ip1j - u_ij;
                            double du2 = u_im1j - u_ij;
                            double w1 = 1.0 / (du1 * du1 + EPS);
                            double w2 = 1.0 / (du2 * du2 + EPS);

                            double du_dx = (w1 * du1 - w2 * du2) / (w1 + w2) / dx;
                            cells[i][j].uWest[var] = cells[i][j].U[rkStep][var] - du_dx * dx / 2.0;
                            cells[i][j].uEast[var] = cells[i][j].U[rkStep][var] + du_dx * dx / 2.0;

                            du1 = u_ijp1 - u_ij;
                            du2 = u_ijm1 - u_ij;
                            w1 = 1.0 / (du1 * du1 + EPS);
                            w2 = 1.0 / (du2 * du2 + EPS);

                            double du_dy = (w1 * du1 - w2 * du2) / (w1 + w2) / dy;
                            cells[i][j].uSouth[var] = cells[i][j].U[rkStep][var] - du_dy * dy / 2.0;
                            cells[i][j].uNorth[var] = cells[i][j].U[rkStep][var] + du_dy * dy / 2.0;
                        }
                    }
                }
                break;
            default:
                throw new UnsupportedOperationException("This reconstruction type is not defined yet!");
        }
    }
}
