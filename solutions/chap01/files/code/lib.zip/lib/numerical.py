# Copyright (c) Sourabh Bhat
# Computer programs to solve problems from Compressible Fluid Flow (P. Oosthuizen, W. E. Carscallen)
# Program written by Sourabh Bhat (mail.spbhat@gmail.com)

import numpy as np


def diff(func, at, h=1e-3):
    return (func(at + h) - func(at - h)) / (2.0 * h)


'''
Solve equation using Newton-Raphson method
'''


def solve_nr(func, init=0, epsilon=1e-8, max_iter=500):
    x = init
    for i in range(max_iter):
        fx = func(x)
        if np.abs(fx) < epsilon:
            break

        x = x - fx / diff(func, x)

        if i == max_iter - 1:
            raise Exception("Newton-Raphson method did not converge with initial guess of %f" % init)

    return x


if __name__ == '__main__':
    def test_func(x):
        return x ** 2


    print(diff(test_func, 3))
    print(solve_nr(test_func, 1))


    def test_func_1(x):
        return x ** 2 - 2


    print(diff(test_func_1, -3))
    print(solve_nr(test_func_1, 2))
