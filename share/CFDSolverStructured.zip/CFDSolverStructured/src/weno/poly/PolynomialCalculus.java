package weno.poly;

import java.util.ArrayList;

public class PolynomialCalculus {
    public static void main(String[] args) {
        Monomial m1 = new Monomial(-1.5, -2);
        Monomial m2 = new Monomial(1000, 0);
        Monomial m3 = new Monomial(1.00054, -5);
        Monomial m4 = new Monomial(-1234.78, 100);
        Monomial m5 = new Monomial(78.98, -23);
        System.out.println(m1);
        System.out.println("After differentiation: " + m1.differentiate());
        System.out.println("After integration: " + m1.integrate());
        ArrayList<Monomial> monomials = new ArrayList<Monomial>();
        monomials.add(m1);
        monomials.add(m2);
        monomials.add(m3);
        monomials.add(m4);
        monomials.add(m5);
        Polynomial p1 = new Polynomial(monomials);
        System.out.println(p1);
        System.out.println("After differentiation: " + p1.differentiate());
        System.out.println("After integration: " + p1.integrate());
        Polynomial p2 = new Polynomial(monomials);
        p1.add(p2);
        System.out.println(p1);
        p1.sort();
        System.out.println("After sorting: " + p1);
        p1.reduce();
        System.out.println("After reduction: " + p1);
    }
}
