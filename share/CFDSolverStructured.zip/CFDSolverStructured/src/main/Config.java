package main;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.stream.Collectors;

public class Config {
    private Config() {}

    public static final int NUM_X_CELLS = 80;
    public static final int NUM_Y_CELLS = 80;
    public static final int NUM_GHOST_CELLS = 4;
    public static final int NUM_RK_STEPS = 3;
    public static final double STOPPING_TIME = 10.0;
    public static final int MAX_TIME_ITER = 100000;
    public static final double MIN_X = -1.0;
    public static final double MAX_X = 1.0;
    public static final double MIN_Y = -1.0;
    public static final double MAX_Y = 1.0;
    public static final double COURANT_NUM = 0.8;
    public static final ReconstructionTypes RECONST_TYPE = ReconstructionTypes.FIRST_ORDER;

    public static final String BASE_PATH = "./out/";

    
    
    
    
    
    
    // For printing out the fields of the config file (uses Java Reflection)
    static String configToString() {

        Field[] fields = Config.class.getFields();
        String str = Arrays.stream(fields)
                .map(field -> formatField(field))
                .collect(Collectors.joining("\n"));
        return str;
    }

    private static String formatField(Field field) {
        String str = "";
        try {
            str = field.getName() + " : " + field.get(null);
        } catch (IllegalAccessException ex) {
        }
        return str;
    }
}
