from numpy import loadtxt, sqrt
from glob import glob
from pylab import plot

fileNames = glob("./out/Solution*.dat")
fileNames.sort()

init_file = fileNames[0]
soln_file = fileNames[-1]
f = file(init_file, 'r')
xCells = int(f.readline().split(":")[1])
numGhostCells = int(f.readline().split(":")[1])
time = float(f.readline().split(":")[1])
f.close()
x_init,u_init = loadtxt(init_file, skiprows=3, unpack=True)
x_soln,u_soln = loadtxt(soln_file, skiprows=3, unpack=True)

errorL1 = sqrt(sum((u_soln[numGhostCells:-numGhostCells] - u_init[numGhostCells:-numGhostCells])**2) / xCells)
print(errorL1)

x = x_init[numGhostCells:-numGhostCells]; u = u_init[numGhostCells:-numGhostCells];
plot(x, u)
x = x_soln[numGhostCells:-numGhostCells]; u = u_soln[numGhostCells:-numGhostCells];
plot(x, u)