# Copyright (c) Sourabh Bhat
# Computer programs to solve problems from Compressible Fluid Flow (P. Oosthuizen, W. E. Carscallen)
# Program written by Sourabh Bhat (mail.spbhat@gmail.com)

"""
Bernoulli's equation, neglecting potential energy
"""

from math import sqrt


def v2(p1, v1, p2, rho):
    return sqrt(v1 * v1 + 2.0 / rho * (p1 - p2))


def p2(p1, v1, v2, rho):
    return p1 + rho / 2.0 * (v1 * v1 - v2 * v2)
