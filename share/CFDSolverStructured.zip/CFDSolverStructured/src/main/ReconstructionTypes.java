package main;

public enum ReconstructionTypes {

    FIRST_ORDER, LAX_WENDROFF, BEAM_WARMING, FROMM,
    LIMITED_LW, LIMITED_BW, WENO, SDWLS_L;
}
