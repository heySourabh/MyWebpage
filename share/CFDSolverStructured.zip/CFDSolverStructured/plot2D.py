import numpy as np
import matplotlib.pyplot as plt
from glob import glob
import os

plt.ioff()

fileNames = glob("./out/Solution*.dat")
fileNames.sort()

fig = plt.figure()
ax = fig.add_subplot(111)
for fileName in fileNames:
    print(fileName)
    f = open(fileName, 'r')
    xCells = int(f.readline().split(":")[1])
    yCells = int(f.readline().split(":")[1])
    numGhostCells = int(f.readline().split(":")[1])
    time = float(f.readline().split(":")[1])
    f.close()
    
    x, y, h, hu, hv = np.loadtxt(fileName, skiprows=4, unpack=True)
    x = np.reshape(x, (xCells + 2 * numGhostCells, yCells + 2 * numGhostCells))
    y = np.reshape(y, (xCells + 2 * numGhostCells, yCells + 2 * numGhostCells))
    h = np.reshape(h, (xCells + 2 * numGhostCells, yCells + 2 * numGhostCells))
    plt.cla()
    plt.clf()
    plt.xticks([])
    plt.yticks([])
    plt.contourf(x, y, h, 100)
    plt.axes().set_aspect("equal")
    #plt.colorbar()
    plt.title("Time=%5.3f"%time)
    plt.colorbar()
    fig.savefig(fileName.replace(".dat", ".png"))

#plt.show()
os.system("eog " + fileNames[0].replace(".dat", ".png"))
