# Copyright (c) Sourabh Bhat
# Computer programs to solve problems from Compressible Fluid Flow (P. Oosthuizen, W. E. Carscallen)
# Program written by Sourabh Bhat (mail.spbhat@gmail.com)

"""
Equation of state using ideal gas equation p = rho*R*T
"""


def p(rho, T, R=287.0):
    return rho * R * T


def rho(p, T, R=287.0):
    return p / R / T


def T(p, rho, R=287.0):
    return p / R / rho


def R(molar_mass):
    universal_gas_constant = 8314
    return universal_gas_constant / molar_mass
