package weno.poly;

import java.util.ArrayList;
import java.util.Collections;
import weno.matrixsolver.MatrixSolver;

public class Polynomial {

    ArrayList<Monomial> monomialList;

    public Polynomial(ArrayList<Monomial> monomialList) {
        this.monomialList = new ArrayList<>();
        this.monomialList.addAll(monomialList);
    }

    public Polynomial() {
        monomialList = new ArrayList<>();
    }

    public double getValueAt(double x) {
        double value = 0.0;
        for (Monomial monomial : monomialList) {
            value += monomial.coeff * Math.pow(x, monomial.exponent);
        }

        return value;
    }

    public void add(Polynomial polynomial) {
//        polynomial.monomialList.stream().forEach((monomial) -> {
//            add(monomial);
//        });
polynomial.monomialList.stream().forEach((monomial) -> {
    add(monomial);
        });
    }

    public void add(Monomial monomial) {
        monomialList.add(monomial);
    }

    public Polynomial times(Polynomial otherPolynomial) {
        Polynomial newPolynomial = new Polynomial();
//        this.monomialList.stream().forEach((thisMonomial) -> {
//            otherPolynomial.monomialList.stream().forEach((otherMonomial) -> {
//                newPolynomial.add(thisMonomial.times(otherMonomial));
//            });
//        });

        for (Monomial thisMonomial : this.monomialList) {
            for (Monomial otherMonomial : otherPolynomial.monomialList) {
                newPolynomial.add(thisMonomial.times(otherMonomial));
            }
        }
        newPolynomial.reduce();
        newPolynomial.sort();

        return newPolynomial;
    }

    public Polynomial times(double scalar) {
        Polynomial newPolynomial = new Polynomial();
        for (Monomial monomial : this.monomialList) {
            newPolynomial.add(monomial.times(scalar));
        }

        return newPolynomial;
    }

    public Polynomial differentiate() {
        Polynomial newPolynomial = new Polynomial();
//        monomialList.stream().filter((monomial) -> (monomial.exponent != 0)).forEach((monomial) -> {
//            newPolynomial.add(monomial.differentiate());
//        });

        for (Monomial monomial : monomialList) {
            if (monomial.exponent != 0) {
                newPolynomial.add(monomial.differentiate());
            }
        }

        newPolynomial.reduce();
        newPolynomial.sort();
        return newPolynomial;
    }

    public Polynomial integrate() {
        Polynomial newPolynomial = new Polynomial();
//        monomialList.stream().forEach((monomial) -> {
//            newPolynomial.add(monomial.integrate());
//        });
        
        for(Monomial monomial : monomialList) {
            newPolynomial.add(monomial.integrate());
        }

        newPolynomial.reduce();
        newPolynomial.sort();
        return newPolynomial;
    }

    public static Polynomial interpolate(double[] x, double[] f) {
        int size = x.length;
        if (f.length != size) {
            throw new IllegalArgumentException("Size of x & f must be same");
        }
        double[][] A = new double[size][size];
        double[] b = new double[size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                A[i][j] = Math.pow(x[i], j);
            }
            b[i] = f[i];
        }

        double[] coeffs = MatrixSolver.gaussElim(A, b);

        Polynomial interpPoly = new Polynomial();
        for (int i = 0; i < size; i++) {
            interpPoly.add(new Monomial(coeffs[i], i));
        }

        return interpPoly;
    }

    /**
     * Combines monomial's in this polynomial with same exponent. In other
     * words, after this operation the polynomial will not have duplicate
     * exponents.
     */
    public void reduce() {
        for (int i = 0; i < monomialList.size(); i++) {
            Monomial a = monomialList.get(i);
            for (int j = i + 1; j < monomialList.size(); j++) {
                Monomial b = monomialList.get(j);
                if (a.exponent == b.exponent) {
                    a.coeff += b.coeff;
                    monomialList.remove(j);
                }
            }
        }
    }

    public void sort() {
        Collections.sort(monomialList);
    }

    @Override
    public String toString() {
        if (monomialList.isEmpty()) {
            return "";
        }
        Monomial monomial = monomialList.get(0);
        String str = String.format("%f * x^{%d}", monomial.coeff, monomial.exponent);
        for (int i = 1; i < monomialList.size(); i++) {
            monomial = monomialList.get(i);
            if (monomial.coeff < 0) {
                str += " - ";
            } else {
                str += " + ";
            }
            str += String.format("%f * x^{%d}", Math.abs(monomial.coeff), monomial.exponent);
        }

        return str;
    }
}
