package weno.weno;
public class ReconstructedValues {
    /**
     * Value at i - 1/2
     */
    public double value_imh;
    /**
     * Value at i + 1/2
     */
    public double value_iph;

    public ReconstructedValues(double value_imh, double value_iph) {
        this.value_imh = value_imh;
        this.value_iph = value_iph;
    }

    @Override
    public String toString() {
        return "value_i+1/2 = " + value_iph + ", value_i-1/2 = " + value_imh;
    }
}
