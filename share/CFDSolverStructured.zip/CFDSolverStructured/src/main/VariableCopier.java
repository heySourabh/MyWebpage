package main;

public class VariableCopier {

    private VariableCopier() {
    }

    public static void copyToZerothRKStep(Cell[][] cells) {
        for (int i = Config.NUM_GHOST_CELLS; i < Config.NUM_X_CELLS + Config.NUM_GHOST_CELLS; i++) {
            for (int j = Config.NUM_GHOST_CELLS; j < Config.NUM_Y_CELLS + Config.NUM_GHOST_CELLS; j++) {
                for (int var = 0; var < Cell.NUM_VARS; var++) {
                    cells[i][j].U[0][var] = cells[i][j].U[Config.NUM_RK_STEPS][var];
                }
            }
        }
    }

}
