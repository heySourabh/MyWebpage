package main;
public class Cell {
    public final static int NUM_VARS = 3;
    
    public double[][] U = new double[Config.NUM_RK_STEPS + 1][NUM_VARS];
    public double[] uWest = new double[NUM_VARS];
    public double[] uEast = new double[NUM_VARS];
    public double[] uSouth = new double[NUM_VARS];
    public double[] uNorth = new double[NUM_VARS];
    public double cx;
    public double cy;
    public double dx;
    public double dy;
    public double[] totalFlux = new double[NUM_VARS];
}
