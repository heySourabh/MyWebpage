package main;

import static java.lang.Math.*;

public class SolutionInitializer {

    private SolutionInitializer() {
    }

    public static void initializeSolution(Cell[][] cells) {
        int rkStep = 0;
        for (Cell[] cellRow : cells) {
            for (Cell cell : cellRow) {
//                if (cell.cx > -0.25 && cell.cx < 0.25 && cell.cy > -0.25 && cell.cy < 0.25) {
//                    cell.u[rkStep] = 1.0;
//                } else {
//                    cell.u[rkStep] = 0.0;
//                }
                double x = cell.cx;
                double y = cell.cy;
                
                double rOffsetX = 0;
                double rOffsetY = 0;
                double rSqr = pow(x - rOffsetX, 2.0) + pow(y - rOffsetY, 2.0);
                double r = sqrt(rSqr);
                double[] initValues = {
                    //0.01 + 1.0 * exp(-(rSqr) / (0.2 * 0.2) / 2.0),
                    //x < -0.5 ? 1.0 : 0.01,
                    //((x < -0.5 && y < -0.5) || (x > 0.5 && y > 0.5)) ? 1.0 : 0.01,
                    //r < 0.75 ? 1.0 : 0.01,
                    (r < 0.25) ? 0.01 : (x < -0.5 && y < -0.5) ? 1.0 : 0.5,
                    //r > 1.9 ? 1.0 : 0.01,
                    //r < 0.5 ? 1.0 : 0.01,
                    0.0,
                    0.0
                };
                System.arraycopy(initValues, 0, cell.U[rkStep], 0, Cell.NUM_VARS);
            }
        }
    }
}
