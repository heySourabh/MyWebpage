from numpy import loadtxt
from pylab import figure, ioff
from glob import glob
import os

ioff()
folder = "./out/"
fileNames = glob(folder + "Solution*.dat")
fileNames.sort()

fig = figure()
ax = fig.add_subplot(111)
f = file(fileNames[-1], 'r')
xCells = int(f.readline().split(":")[1])
numGhostCells = int(f.readline().split(":")[1])
time = float(f.readline().split(":")[1])
f.close()

x,u = loadtxt(fileNames[-1], skiprows=3, unpack=True)
ax.plot(x, u, lw=5)
ax.plot(x, u, ".")

x,u = loadtxt(fileNames[0], skiprows=3, unpack=True)
ax.plot(x, u, "--", lw=2)
#ax.plot(x, u, ".")
#ax.set_xlim(-1, 1)
ax.set_ylim(-1.1, 1.1)
ax.set_title("Time=%5.3f"%time)
outfileName = folder + "result.png"
fig.savefig(outfileName)

os.system("eog " + outfileName)
