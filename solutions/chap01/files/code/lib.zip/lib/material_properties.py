# Copyright (c) Sourabh Bhat
# Computer programs to solve problems from Compressible Fluid Flow (P. Oosthuizen, W. E. Carscallen)
# Program written by Sourabh Bhat (mail.spbhat@gmail.com)

def R(molar_mass):
    return 8314 / molar_mass


def cp(R=287, gamma=1.4):
    return R * gamma / (gamma - 1.0)


def cv(R=287, gamma=1.4):
    return R / (gamma - 1.0)


if __name__ == '__main__':
    print("Default cp = ", cp())
    print("Default cv = ", cv())
