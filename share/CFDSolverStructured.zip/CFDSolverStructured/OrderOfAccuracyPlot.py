import numpy as np
import matplotlib.pyplot as plt
import itertools

inputFileName = "SineCosineData.dat"
inputFile = open(inputFileName, "r")
line = inputFile.readline()
equation = line.split(":")[1].strip()
print(equation)
numOfSchemes = 5
marker = itertools.cycle(('s', 'v', '<', 'o', '^'))
for _ in range(numOfSchemes):
    line = inputFile.readline()
    schemeName = line.split(":")[1].strip()
    line = inputFile.readline()
    meshSize = [0] * 4
    eL1 = [0] * 4
    eL2 = [0] * 4
    eLinf = [0] * 4
    orderL1 = [0] * 4
    orderL2 = [0] * 4
    orderLinf = [0] * 4
    meshSize[0], eL1[0], eL2[0], eLinf[0] = inputFile.readline().split()
    for i in range(1, 4):
        meshSize[i], eL1[i], eL2[i], eLinf[i], orderL1[i], orderL2[i], orderLinf[i] = inputFile.readline().split()
    
    for i in range(4):
        meshSize[i] = int(meshSize[i])
        eL1[i] = float(eL1[i])
        eL2[i] = float(eL2[i])
        eLinf[i] = float(eLinf[i])
        orderL1[i] = float(orderL1[i])
        orderL2[i] = float(orderL2[i])
        orderLinf[i] = float(orderLinf[i])
    
    plt.loglog(meshSize, eL1, "-", lw=5, marker = marker.__next__(), markersize=10, label=schemeName)
    
    print(schemeName)

plt.xticks([20, 40, 80, 160, 320])
plt.axes().set_xticklabels([20, 40, 80, 160, 320])
plt.title(equation, fontsize=20, y=1.01)
plt.xlabel("$\sqrt{N_x\,N_y}$", fontsize=16)
plt.ylabel("Error", fontsize=16)
plt.grid()
plt.legend(loc="best")
plt.savefig(inputFileName + ".png", bbox_inches="tight")
plt.show()