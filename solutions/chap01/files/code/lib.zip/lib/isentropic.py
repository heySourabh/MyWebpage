# Copyright (c) Sourabh Bhat
# Computer programs to solve problems from Compressible Fluid Flow (P. Oosthuizen, W. E. Carscallen)
# Program written by Sourabh Bhat (mail.spbhat@gmail.com)

"""
Relations for isentropic flow along two points on a streamline 1-2
"""


def p2_by_p1(T2_by_T1, gamma=1.4):
    return T2_by_T1 ** (gamma / (gamma - 1.0))


def p2(p1, T2_by_T1, gamma=1.4):
    return p1 * p2_by_p1(T2_by_T1, gamma)


def T2_by_T1(p2_by_p1, gamma=1.4):
    return p2_by_p1 ** ((gamma - 1) / gamma)


def T2(T1, p2_by_p1, gamma=1.4):
    return T1 * T2_by_T1(p2_by_p1, gamma)
