package main;

public class ErrorCalculator {

    double errorL1, errorL2, errorLinf;

    public ErrorCalculator(Cell[][] cells) {
        // get the initial distribution
        Cell[][] initCells = new Cell[cells.length][cells[0].length];
        for (int i = 0; i < initCells.length; i++) {
            for (int j = 0; j < initCells[0].length; j++) {
                initCells[i][j] = new Cell();
                initCells[i][j].cx = cells[i][j].cx;
                initCells[i][j].cy = cells[i][j].cy;
                initCells[i][j].dx = cells[i][j].dx;
                initCells[i][j].dy = cells[i][j].dy;

            }
        }
        SolutionInitializer.initializeSolution(initCells);

        errorL1 = 0.0;
        errorL2 = 0.0;
        errorLinf = 0.0;
        for (int i = Config.NUM_GHOST_CELLS; i < Config.NUM_X_CELLS + Config.NUM_GHOST_CELLS; i++) {
            for (int j = Config.NUM_GHOST_CELLS; j < Config.NUM_Y_CELLS + Config.NUM_GHOST_CELLS; j++) {
                double error = Math.abs(initCells[i][j].U[0][0] - cells[i][j].U[0][0]);
                errorL1 += error;
                errorL2 += error * error;
                errorLinf = Math.max(error, errorLinf);
            }
        }
        int numCells = Config.NUM_X_CELLS * Config.NUM_Y_CELLS;
        errorL1 /= numCells;
        errorL2 = Math.sqrt(errorL2 / numCells);
    }

    @Override
    public String toString() {
        return String.format("%-25s%-25s%-25s\n"
                + "%-25.15e%-25.15e%-25.15e", "ErrorL1", "ErrorL2", "ErrorLinf", errorL1, errorL2, errorLinf);
    }
}
