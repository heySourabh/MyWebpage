package weno.poly;

public class LagrangePolynomial {

    double[] x;
    double[] f;

    public LagrangePolynomial(double[] x, double[] f) {
        this.x = x;
        this.f = f;

        if (x.length != f.length) {
            throw new IllegalArgumentException("The length of x & f must be same!");
        }
    }

    public double lagrangeCoeff(int i, double x) {
        double product = 1.0;
        for (int j = 0; j < this.x.length; j++) {
            if (i == j) {
                continue;
            }
            product *= (x - this.x[j]) / (this.x[i] - this.x[j]);
        }
        return product;
    }

    public double interpolateAt(double x) {
        double sum = 0.0;
        for (int i = 0; i < f.length; i++) {
            sum += lagrangeCoeff(i, x) * f[i];
        }
        return sum;
    }

    public double lagrangeDiffCoeff(int i, double x) {
        double sum = 0.0;
        for (int j = 0; j < this.x.length; j++) {
            if (i == j) {
                continue;
            }
            double product = 1.0;
            for (int k = 0; k < this.x.length; k++) {
                if (k == j || k == i) {
                    continue;
                }
                product *= (x - this.x[k]);
            }
            sum += product;
        }
        double denom = 1.0;
        for (int j = 0; j < this.x.length; j++) {
            if (i == j) {
                continue;
            }
            denom *= (this.x[i] - this.x[j]);
        }

        return sum / denom;
    }

    double derivativeAt(double x) {
        double sum = 0.0;
        for (int i = 0; i < f.length; i++) {
            sum += lagrangeDiffCoeff(i, x) * f[i];
        }

        return sum;
    }
}
