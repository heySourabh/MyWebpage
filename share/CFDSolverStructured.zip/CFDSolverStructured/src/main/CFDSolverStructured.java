package main;

public class CFDSolverStructured {

    public static void main(String[] args) {
        System.out.println(Config.configToString());

//*** Overall Structure of CFD code ***
//
//Start
//
//    Create data structure (grid)
//    Populate geometry information in data structure
//    Initialize the solution variable(s)
//    Write intial data file (initial solution)
//    
//    time = 0
//    lastTimeStep = false
//    Loop for MAX_NUM_TIME_ITER:
//        calculate dt based on COURANT_NUM
//        if time + dt > STOPPING_TIME:
//            dt = STOPPING_TIME - time
//            lastTimeStep = true
//        
//        for NUM_RK_STEPS:
//            Apply Boundary Conditions
//            reconstructVariables
//            calculateFlux
//            updateCellAverage
//        
//        copyCellAverageToLevelZero
//        
//        time += dt
//        if lastTimeStep:
//            break
//
//    Write final solution data file
//
//End
        Cell[][] cells = new Cell[Config.NUM_X_CELLS + 2 * Config.NUM_GHOST_CELLS]
                [Config.NUM_Y_CELLS + 2 * Config.NUM_GHOST_CELLS];
        double dx = (Config.MAX_X - Config.MIN_X) / Config.NUM_X_CELLS;
        double dy = (Config.MAX_Y - Config.MIN_Y) / Config.NUM_Y_CELLS;
        for (int i = 0; i < cells.length; i++) {
            for (int j = 0; j < cells[0].length; j++) {
                cells[i][j] = new Cell();
                cells[i][j].dx = dx;
                cells[i][j].dy = dy;
                cells[i][j].cx = Config.MIN_X + dx * (i + 0.5 - Config.NUM_GHOST_CELLS);
                cells[i][j].cy = Config.MIN_Y + dy * (j + 0.5 - Config.NUM_GHOST_CELLS);
            }
        }

        SolutionInitializer.initializeSolution(cells);
        double time = 0.0;
        SolutionFileWriter.writeSolutionFile(cells, time);
        boolean lastTimeStep = false;

        long startTime = System.currentTimeMillis();
        for (int timeIter = 0; timeIter < Config.MAX_TIME_ITER; timeIter++) {
            double dt = TimeStepCalculator.getTimeStep(cells);
            if (time + dt > Config.STOPPING_TIME) {
                dt = Config.STOPPING_TIME - time;
                lastTimeStep = true;
            }

            for (int rkStep = 0; rkStep < Config.NUM_RK_STEPS; rkStep++) {
                GhostCellUpdater.updateGhostCells(cells, rkStep);
                VariableReconstructor.reconstructVariables(cells, rkStep);
                Flux.calculateFlux(cells, rkStep);
                TimeIntegration.updateCellAverages(cells, rkStep, dt);
            }

            VariableCopier.copyToZerothRKStep(cells);

            time += dt;
            System.out.printf("%d : Time = %f\n", timeIter, time);
            if (lastTimeStep) {
                break;
            }
            if ((timeIter + 1) % 10 == 0) {
                SolutionFileWriter.writeSolutionFile(cells, time);
            }
        }
        long endTime = System.currentTimeMillis();
        System.out.println("Compute Time = " + (endTime - startTime));
        //System.out.println(new ErrorCalculator(cells));

        SolutionFileWriter.writeSolutionFile(cells, time);
        
        System.out.println(Config.configToString());
    }
}
