package weno.poly;

public class Monomial implements Comparable<Monomial> {

    double coeff;
    int exponent;

    /**
     * Constructor for monomial coeff * x^exponent.
     *
     * @param coeff coefficient of the monomial
     * @param exponent exponent of the monomial
     */
    public Monomial(double coeff, int exponent) {
        this.coeff = coeff;
        this.exponent = exponent;
    }

    public Monomial differentiate() {
        double newCoeff;
        int newExponent;
        if (exponent != 0) {
            newCoeff = coeff * exponent;
            newExponent = exponent - 1;

        } else {
            newCoeff = 0.0;
            newExponent = 0;
        }

        return new Monomial(newCoeff, newExponent);
    }

    public Monomial integrate() {
        double newCoeff;
        int newExponent;

        if (exponent == -1) {
            throw new ArithmeticException("Cannot integrate mononial x^{-1}, not a polynomial after integration, divide by zero exception.");
        } else {
            newCoeff = coeff / (exponent + 1);
            newExponent = exponent + 1;
        }

        return new Monomial(newCoeff, newExponent);
    }

    public Monomial times(Monomial otherMonomial) {
        double newCoeff = this.coeff * otherMonomial.coeff;
        int newExponent = this.exponent + otherMonomial.exponent;

        return new Monomial(newCoeff, newExponent);
    }
    
    public Monomial times(double scalar) {
        double newCoeff = this.coeff * scalar;
        
        return new Monomial(newCoeff, this.exponent);
    }

    @Override
    public int compareTo(Monomial otherMonomial) {
        return this.exponent - otherMonomial.exponent;
    }

    @Override
    public String toString() {
        return String.format("%f * x^{%d}", coeff, exponent);
    }
}
