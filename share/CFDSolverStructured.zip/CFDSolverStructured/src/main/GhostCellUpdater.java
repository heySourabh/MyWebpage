package main;

public class GhostCellUpdater {

    private GhostCellUpdater() {
    }

    public static void updateGhostCells(Cell[][] cells, int rkStep) {
        // left and right side of the domain
        for (int j = 0; j < cells[0].length; j++) {
            for (int ghostCell = 0; ghostCell < Config.NUM_GHOST_CELLS; ghostCell++) {
                int var = 0;
                cells[ghostCell][j].U[rkStep][var]
                        = cells[2 * Config.NUM_GHOST_CELLS - ghostCell - 1][j].U[rkStep][var];
                cells[Config.NUM_X_CELLS + Config.NUM_GHOST_CELLS + ghostCell][j].U[rkStep][var]
                        = cells[Config.NUM_X_CELLS + Config.NUM_GHOST_CELLS - ghostCell - 1][j].U[rkStep][var];
                
                var = 1;
                cells[ghostCell][j].U[rkStep][var]
                        = -cells[2 * Config.NUM_GHOST_CELLS - ghostCell - 1][j].U[rkStep][var];
                cells[Config.NUM_X_CELLS + Config.NUM_GHOST_CELLS + ghostCell][j].U[rkStep][var]
                        = -cells[Config.NUM_X_CELLS + Config.NUM_GHOST_CELLS - ghostCell - 1][j].U[rkStep][var];
                
                var = 2;
                cells[ghostCell][j].U[rkStep][var]
                        = cells[2 * Config.NUM_GHOST_CELLS - ghostCell - 1][j].U[rkStep][var];
                cells[Config.NUM_X_CELLS + Config.NUM_GHOST_CELLS + ghostCell][j].U[rkStep][var]
                        = cells[Config.NUM_X_CELLS + Config.NUM_GHOST_CELLS - ghostCell - 1][j].U[rkStep][var];
            }
        }

        // bottom and top cells
        for (int i = 0; i < cells.length; i++) {
            for (int ghostCell = 0; ghostCell < Config.NUM_GHOST_CELLS; ghostCell++) {
                int var = 0;
                cells[i][ghostCell].U[rkStep][var]
                        = cells[i][2 * Config.NUM_GHOST_CELLS - ghostCell - 1].U[rkStep][var];
                cells[i][Config.NUM_Y_CELLS + Config.NUM_GHOST_CELLS + ghostCell].U[rkStep][var]
                        = cells[i][Config.NUM_Y_CELLS + Config.NUM_GHOST_CELLS - ghostCell - 1].U[rkStep][var];

                var = 1;
                cells[i][ghostCell].U[rkStep][var]
                        = cells[i][2 * Config.NUM_GHOST_CELLS - ghostCell - 1].U[rkStep][var];
                cells[i][Config.NUM_Y_CELLS + Config.NUM_GHOST_CELLS + ghostCell].U[rkStep][var]
                        = cells[i][Config.NUM_Y_CELLS + Config.NUM_GHOST_CELLS - ghostCell - 1].U[rkStep][var];

                var = 2;
                cells[i][ghostCell].U[rkStep][var]
                        = -cells[i][2 * Config.NUM_GHOST_CELLS - ghostCell - 1].U[rkStep][var];
                cells[i][Config.NUM_Y_CELLS + Config.NUM_GHOST_CELLS + ghostCell].U[rkStep][var]
                        = -cells[i][Config.NUM_Y_CELLS + Config.NUM_GHOST_CELLS - ghostCell - 1].U[rkStep][var];
            }
        }
    }
}
